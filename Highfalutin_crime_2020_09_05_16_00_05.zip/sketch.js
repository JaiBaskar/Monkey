var monkey, monkey_running, obstacle, banana, scene, ground, obstacleImage;
var score = 0;


function preload(){
monkey_running = loadAnimation("Monkey_01.png","Monkey_02.png",
                                 "Monkey_02.png","Monkey_04.png","Monkey_05.png",
                                 "Monkey_06.png","Monkey_07.png","Monkey_08.png",
                                 "Monkey_09.png","Monkey_10.png");
 sceneImage = loadImage("jungle.png");
  
  
}

function setup() {
  createCanvas(400, 400);

  scene = createSprite(0,200,400,400);
  scene.addImage(sceneImage);
  scene.scale = 2;
  monkey = createSprite(50,180,20,50);
  monkey.addAnimation("running",monkey_running);
  monkey.scale = 0.1;
  
  ground = createSprite(200,380,400,20);
 
  
  bananaGroup = createGroup();
  obstacleGroup = createGroup();

  
}

function draw() {
  background(255);
   if (keyDown("space")) {
   monkey.velocityY = -8;
 }
monkey.velocityY = monkey.velocityY + 0.8;

text("score :"+score,200,160);

if (monkey.isTouching(bananaGroup)) {
  score = score+2;
  bananaGroup.destroyEach();

  
  
}
if (monkey.isTouching(obstacleGroup)) {
  score = score-5;
  obstacleGroup.destroyEach();

  
  
}


 
 food();
 
 obstacle();
 
 
 createEdgeSprites();
 monkey.collide(ground);
  
    
  drawSprites();
  

}

function food(){
  if (frameCount%80 === 0) {
    var food = createSprite(400,random(300,360),10,10);
    food.scale = 0.03;
    food.velocityX = -5;
    food.y = random(360,300);
    food.lifetime = 80;
    bananaGroup.add(food);
  }
  
}

function obstacle(){
  if (frameCount%300 === 0) {
    var obstacle = createSprite(400,360,20,20);
    obstacle.addImage(
    obstacle.scale = 0.25;
    obstacle.velocityX = -5;
    obstacle.lifetime = 80;
    obstacleGroup.add(obstacle);
  }
  
}
  